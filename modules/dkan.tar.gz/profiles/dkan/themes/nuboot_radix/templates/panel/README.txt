
This directory should be used to place panels template files.
